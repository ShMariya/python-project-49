#!/usr/bin/env python3
from brain_games.engine import calc


def main():
    calc()


if __name__ == '__main__':
    main()
