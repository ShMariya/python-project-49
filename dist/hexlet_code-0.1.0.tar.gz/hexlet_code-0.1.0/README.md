### Hexlet tests and linter status:
[![Actions Status](https://github.com/ShMariya/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ShMariya/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/2911b192f2dff2f23884/maintainability)](https://codeclimate.com/github/ShMariya/python-project-49/maintainability)

https://asciinema.org/a/hsy1nNJVq9d2zBRLBMNJI08JD

https://asciinema.org/a/v9HKuTdUmT5wpSsISlDDFwykP


https://asciinema.org/a/TduFRqkBaDNhvvt0RtTa1rXRy

