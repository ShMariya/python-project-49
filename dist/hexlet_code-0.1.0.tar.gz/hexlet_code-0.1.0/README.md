### Hexlet tests and linter status:
[![Actions Status](https://github.com/ShMariya/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ShMariya/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/2911b192f2dff2f23884/maintainability)](https://codeclimate.com/github/ShMariya/python-project-49/maintainability)

https://asciinema.org/a/vbbL90w6IoOTIw8JCU9Q21PQ7

https://asciinema.org/a/kwCACMb530PUk92DkEraCYO3J

https://asciinema.org/a/GbeUclZViXZ7B7tquiWZS1Uxm

https://asciinema.org/a/2yrTK7WAqHENIwuaPPXNYiMvH

https://asciinema.org/a/QE1fTp4CCe2aFqRNLBjWaHkCy


