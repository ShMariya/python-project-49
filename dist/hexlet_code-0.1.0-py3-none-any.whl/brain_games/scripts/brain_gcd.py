#!/usr/bin/env python3
from brain_games.engine import find_gcd

def main():
    find_gcd()

if __name__ == '__main__':
    main()