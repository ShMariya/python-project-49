#!/usr/bin/env python3
from brain_games.engine import find_missing_number

def main():
    find_missing_number()

if __name__ == '__main__':
    main()